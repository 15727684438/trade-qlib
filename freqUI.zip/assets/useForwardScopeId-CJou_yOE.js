import{L as e}from"./runtime-core.esm-bundler-BKdLzFmX.js";function t(){let t=e()?.vnode?.scopeId;return t?{[t]:``}:{}}export{t};
//# sourceMappingURL=useForwardScopeId-CJou_yOE.js.map